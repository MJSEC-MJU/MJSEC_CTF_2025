module.exports = {
  TRUE_DATE: 'xx, xx xx xxxx xx:xx:xx GMT',
  TRUE_ETAG: 'etagxxxx',
  FLAG: 'MJSEC{fake_flag}'
};
