# The Flag That Should Not Exist

> "Sometimes, the server says nothing... and yet reveals everything."

## 문제 설명

이 서버는 이미 삭제된 `/flag.txt` 파일을 제공합니다. 하지만 조건이 맞으면 존재하지 않아야 할 플래그가 헤더에 숨어 전송됩니다. 서버는 당신의 요청을 기억하고, 로그를 남깁니다.  
**당신의 임무는 이 '존재하지 않는 플래그'를 추출하는 것.**

---

"진짜 삭제된 건 파일이 아니라, 당신의 의심일지도 몰라요."
