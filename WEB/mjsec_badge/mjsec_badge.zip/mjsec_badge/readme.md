# MJSEC_BADGE


## 문제 설명

회장이 MT 기념으로 MJSECBadge를 출시했어요!
근데 Badge 디자인이 정말 너무 실@플 한데요? 
---


